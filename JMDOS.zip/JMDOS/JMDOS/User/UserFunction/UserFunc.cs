﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.User.UserFunction
{
    public static class UserFunc
    {
        public static bool Login(bool IsAuthority)
        {
            if(!IsAuthority)
            {
                string input = string.Empty;
                Console.Write("[Elevation]: Enter default account password : ");
                input = (string)Console.ReadLine();

                if (input == OSVariables.defaultPassword)
                {
                    return true;
                }
                else if (input != OSVariables.defaultPassword)
                {
                    return false;
                }
            }
            else if(IsAuthority)
            {
                string input = string.Empty;
                Console.Write("[Elevation]: Enter authority account password : ");
                input = (string)Console.ReadLine();

                if (input == OSVariables.authorityPassword)
                {
                    return true;
                }
                else if (input != OSVariables.authorityPassword)
                {
                    return false;
                }
            }

            return false;
        }
    }
}
