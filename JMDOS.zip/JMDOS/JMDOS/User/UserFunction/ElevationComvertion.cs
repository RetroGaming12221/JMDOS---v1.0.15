﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.User.UserFunction
{
    public static class ElevationConvertion
    {
        public static string Convert(ElevationType elevationType)
        {
            switch(elevationType)
            {
                case ElevationType.User:
                    return "User";
                case ElevationType.Superior:
                    return "Superior";
                case ElevationType.Authority:
                    return "Authority";
            }
            return "";
        }
    }
}
