﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.User
{
    public enum ElevationType
    {
        User = 0,
        Superior = 1,
        Authority = 2,
    }
}
