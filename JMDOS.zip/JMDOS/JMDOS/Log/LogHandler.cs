﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Log
{
    public static class LogHandler
    {
        public static void AddLog(string Message, LogType LogType)
        {
            try
            {
                OSVariables.logList.Add(new Log(Message, LogType));
            }
            catch
            {
                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to add log", true);
                AddLog("Failed to add log", LogType.Output);
            }
        }

        public static void SaveLog(string filePath)
        {
            try
            {
                for(int i = 0; i < OSVariables.logList.Count; i++)
                {
                    File.WriteAllText(filePath, $"[{OSVariables.logList[i].LogType}]: {OSVariables.logList[i].Message}");
                }
            }
            catch
            {
                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to save log", true);
                AddLog("Failed to save log", LogType.Output);
            }
        }
    }
}
