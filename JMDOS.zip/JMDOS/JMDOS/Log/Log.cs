﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Log
{
    public class Log
    {
        public Log(string message, LogType logType)
        {
            Message = message;
            LogType = logType;
        }

        public string Message { get; set; }
        public LogType LogType { get; set; }
    }
}
