﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

namespace JMDOS.TextEditor
{
    public static class TextEdit
    {
        public static void ProcessInstance(string[] Instance)
        {
            if (Instance[0] == "new")
            {
                TextCanvas.NewInstance();
            }
        }
    }

    internal static class TextCanvas
    {
        public static string[] fileLines;
        public static string fileName;
        public static int CurrentLine = 0;
        public static int listCapacity = 1;

        public static void NewInstance()
        {
            fileLines = new string[1];
            fileName = "New File";

            while(true)
            {
                Cosmos.Core.Memory.Heap.Collect();
                Console.Clear();
                Console.WriteLine($"Text Editor V1.0 - {fileName}");
                TextFunction.Render(fileLines);
                ConsoleKeyInfo ck = Console.ReadKey();
                fileLines[CurrentLine] = TextFunction.Add(fileLines[CurrentLine], ck.KeyChar);

                if(ck.Key == ConsoleKey.Backspace)
                {
                    fileLines[CurrentLine] = TextFunction.Delete(fileLines[CurrentLine]);
                }
                if(ck.Key == ConsoleKey.Enter)
                {
                    TextFunction.NewLines();
                }
            }
        }
    }

    internal static class TextFunction
    {
        public static int LinesCount(ArrayList Lines)
        {
            return Lines.Count;
        }

        public static string Add(string stringLines, char Char)
        {
            string tempCopy = stringLines;
            return tempCopy += Char;
        }

        public static string Delete(string stringLines)
        {
            try
            {
                return string.Empty;
            }
            catch
            {
                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Error occured from Text Editor", true);
                Log.LogHandler.AddLog("Error occured from Text Editor", Log.LogType.Output);
            }
            return "";
        }

        public static void Render(string[] arrayLines)
        {
            for(int i = 0; i < arrayLines.Length; i++)
            {
                Console.WriteLine($"{i + 1}: {arrayLines[i]}");
            }
        }

        public static void NewLines()
        {

        }
    }
}
