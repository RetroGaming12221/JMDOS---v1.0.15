﻿using Cosmos.System.FileSystem;
using Cosmos.System.FileSystem.VFS;
using System;
using System.IO;
using Sys = Cosmos.System;

namespace JMDOS
{
    public class Kernel : Sys.Kernel
    {
        protected override void BeforeRun()
        {
            Console.Clear();
            CosmosVFS VFS = new CosmosVFS();
            VFSManager.RegisterVFS(VFS);

            if(!Directory.Exists(@"0:\System"))
            {
                Directory.CreateDirectory(@"0:\System");
            }
            if(!Directory.Exists(@"0:\System\User"))
            {
                Directory.CreateDirectory(@"0:\System\User");
            }
            if(!Directory.Exists(@"0:\System\Logs"))
            {
                Directory.CreateDirectory(@"0:\System\Logs");
            }
            if(!Directory.Exists(@"0:\System\User\UserData"))
            {
                Directory.CreateDirectory(@"0:\System\User\UserData");
            }

            Console.WriteLine($"JMDOS Build {OSVariables.OSVersion}");
            MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Info, $"Total Storage : {VFS.GetTotalSize(@"0:\")}", false);
            MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Info, $"Free Storage : {VFS.GetTotalFreeSpace(@"0:\")}\n", true);
        }

        protected override void Run()
        {
            Cosmos.Core.Memory.Heap.Collect();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write($"{OSVariables.CurrentUsername}");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("@");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write($"{User.UserFunction.ElevationConvertion.Convert(OSVariables.CurrentElevationType)}-$ ");
            Console.ResetColor();
            string input = Console.ReadLine();
            Log.LogHandler.AddLog(input, Log.LogType.Input);
            Command.CommandFunction.Procces(input);
        }
    }
}
