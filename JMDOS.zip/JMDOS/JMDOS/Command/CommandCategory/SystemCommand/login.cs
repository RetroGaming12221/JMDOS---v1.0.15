﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.SystemCommand
{
    public class login : Command
    {
        public login() : base("login", "Logins into default user or any user created", User.ElevationType.User) { }

        public override void Execute(string[] args)
        {
            try
            {
                if (args[0] == "-d")
                {
                    DefaultLogin();
                }
                else if (args[0] == "-au")
                {
                    AuthorityLogin();
                }
            }
            catch
            {
                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Enter a valid argument", true);
                Log.LogHandler.AddLog("Enter a valid argument", Log.LogType.Output);
            }
        }

        private void DefaultLogin()
        {
            Console.Write("[Login]: Enter default password : ");
            string inp = Console.ReadLine();
            if(inp == OSVariables.defaultPassword)
            {
                OSVariables.CurrentUsername = OSVariables.defaultUsername;
                OSVariables.CurrentElevationType = OSVariables.defaultElevationType;
                OSVariables.CurrentPassword = OSVariables.defaultPassword;
            }
            else if(inp != OSVariables.defaultPassword)
            {
                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Wrong password", true);
                Log.LogHandler.AddLog("Wrong password", Log.LogType.Output);
            }
        }

        private void AuthorityLogin()
        {
            Console.Write("[Login]: Enter superior password : ");
            string inp = Console.ReadLine();
            if (inp == OSVariables.authorityPassword)
            {
                OSVariables.CurrentUsername = OSVariables.authorityUsername;
                OSVariables.CurrentElevationType = OSVariables.authorityElevationType;
                OSVariables.CurrentPassword = OSVariables.authorityPassword;
            }
            else if (inp != OSVariables.authorityPassword)
            {
                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Wrong password", true);
                Log.LogHandler.AddLog("Wrong password", Log.LogType.Output);
            }
        }
    }
}
