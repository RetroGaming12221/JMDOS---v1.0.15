﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.BasicCommand
{
    public class clear : Command
    {
        public clear() : base("clear", "Clears the screen", User.ElevationType.User) { }

        public override void Execute(string[] args)
        {
            Console.Clear();
        }
    }
}
