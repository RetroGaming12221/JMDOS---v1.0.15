﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.BasicCommand
{
    public class osver : Command
    {
        public osver() : base("osver", "Shows current os version", User.ElevationType.User) { }

        public override void Execute(string[] args)
        {
            Console.WriteLine($"{OSVariables.OSVersion}");
        }
    }
}
