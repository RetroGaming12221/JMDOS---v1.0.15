﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.BasicCommand
{
    public class help : Command
    {
        public help() : base("help", "Shows command description", User.ElevationType.User, new string[]
        {
            "Shows command description with simple description, or full description",
            "Example : help [Command]"
        }) { }

        public override void Execute(string[] args)
        {
            if(args.Length == 0)
            {
                for (int i = 0; i < OSVariables.commandList.Count; i++)
                {
                    Console.WriteLine($"{OSVariables.commandList[i].Name.ToUpper()}   {OSVariables.commandList[i].Desc}");
                }
                Console.WriteLine("\n");
            }
            else if(args.Length > 0)
            {
                try
                {
                    for(int j = 0; j < OSVariables.commandList.Count; j++)
                    {
                        if (OSVariables.commandList[j].Name == args[0])
                        {
                            if (OSVariables.commandList[j].FullDesc == null)
                            {
                                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Info, "Command has no full description", true);
                            }
                            else if (OSVariables.commandList[j].FullDesc != null)
                            {
                                for(int i = 0; i < OSVariables.commandList[j].FullDesc.Length; i++)
                                {
                                    Console.WriteLine(OSVariables.commandList[j].FullDesc[i]);
                                }
                            }
                        }
                    }
                }
                catch
                {
                    MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "No argument were inputted or command doesnt exist", true);
                }
            }
        }
    }
}
