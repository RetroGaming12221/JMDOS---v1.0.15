﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.BasicCommand
{
    public class math : Command
    {
        public math() : base("math", "simple math function, add, subtract, multiply, divide(Its stil broken)", User.ElevationType.User) { }

        public override void Execute(string[] args)
        {
            int[] numberList = new int[args.Length - 1];
            int result = 0;

            if (args[0] == "add")
            {
                for(int i = 0; i < numberList.Length; i++)
                {
                    numberList[i] = int.Parse(args[i + 1]);
                }

                for(int i = 0; i < numberList.Length; i++)
                {
                    result += numberList[i];
                }
            }
            else if (args[0] == "subtract")
            {
                for (int i = 0; i < numberList.Length; i++)
                {
                    numberList[i] = int.Parse(args[i + 1]);
                }

                for (int i = 0; i < numberList.Length; i++)
                {
                    
                }
            }
            else if (args[0] == "divide")
            {
                for (int i = 0; i < numberList.Length; i++)
                {
                    numberList[i] = int.Parse(args[i + 1]);
                }

                for (int i = 0; i < numberList.Length; i++)
                {
                    result /= numberList[i];
                }
            }
            else if (args[0] == "multiply")
            {
                for (int i = 0; i < numberList.Length; i++)
                {
                    numberList[i] = int.Parse(args[i + 1]);
                }

                for (int i = 0; i < numberList.Length; i++)
                {
                    result *= numberList[i];
                }
            }

            Console.WriteLine(result);
        }
    }
}
