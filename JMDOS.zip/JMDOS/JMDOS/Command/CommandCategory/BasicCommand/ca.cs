﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.BasicCommand
{
    public class ca : Command
    {
        public ca() : base("ca", "Shows current user", User.ElevationType.User) { }

        public override void Execute(string[] args)
        {
            Console.WriteLine($"{OSVariables.CurrentUsername} / {User.UserFunction.ElevationConvertion.Convert(OSVariables.CurrentElevationType)}");
        }
    }
}
