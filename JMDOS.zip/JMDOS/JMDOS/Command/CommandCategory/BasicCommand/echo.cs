﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.BasicCommand
{
    public class echo : Command
    {
        public echo() : base("echo", "Echo'es user input after the command", User.ElevationType.User) { }

        public override void Execute(string[] args)
        {
            try
            {
                string text = string.Empty;

                for (int i = 0; i < args.Length; i++)
                {
                    if (args[i] == args[0])
                    {
                        text += $"{args[0]}";
                    }
                    else if (i > 0)
                    {
                        text += $" {args[i]}";
                    }
                }

                Console.WriteLine(text);
            }
            catch
            {
                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "No argument were inputted", true);
                Log.LogHandler.AddLog("No argument were inputted", Log.LogType.Output);
            }
        }
    }
}
