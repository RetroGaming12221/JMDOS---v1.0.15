﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.FileCommand
{
    public class file : Command
    {
        public file() : base("file", "create, delete, move, and copy file", User.ElevationType.Superior, new string[]
        {
            "Use to create, delete, move and copy files",
            "file create [Path]",
            "file delete [Path]",
            "file move [Path]",
            "file copy [path]"
        }) { }

        public override void Execute(string[] args)
        {
            if (args[0] == "create")
            {
                try
                {
                    File.Create(args[1]);

                    if (File.Exists(args[1]))
                    {
                        Console.WriteLine($"\"{args[1]}\" Succesfully created");
                    }
                    else if(!File.Exists(args[1]))
                    {
                        MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to create file", true);
                        Log.LogHandler.AddLog("Failed to create file", Log.LogType.Output);
                    }
                }
                catch
                {
                    MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Enter a valid path", true);
                    Log.LogHandler.AddLog("Enter a valid path", Log.LogType.Output);
                }
            }
            else if (args[0] == "delete")
            {
                try
                {
                    File.Delete(args[1]);

                    if (!File.Exists(args[1]))
                    {
                        Console.WriteLine($"\"{args[1]}\" Succesfully deleted");
                    }
                    else if (File.Exists(args[1]))
                    {
                        MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to delete file", true);
                        Log.LogHandler.AddLog("Failed to delete file", Log.LogType.Output);
                    }
                }
                catch
                {
                    MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Enter a valid path", true);
                    Log.LogHandler.AddLog("Enter a valid path", Log.LogType.Output);
                }
            }
            else if (args[0] == "move")
            {
                try
                {
                    File.Copy(args[1], args[2]);

                    if (File.Exists(args[2]))
                    {
                        File.Delete(args[1]);
                        Console.WriteLine($"\"{args[1]}\" Succesfully moved");
                    }
                    else if (!File.Exists(args[2]))
                    {
                        MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to moved file", true);
                        Log.LogHandler.AddLog("Failed to move file", Log.LogType.Output);
                    }
                }
                catch
                {
                    MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Enter a valid path", true);
                    Log.LogHandler.AddLog("Enter a valid path", Log.LogType.Output);
                }
            }
            else if (args[0] == "copy")
            {
                try
                {
                    File.Copy(args[1], args[2]);

                    if (File.Exists(args[2]))
                    {
                        Console.WriteLine($"\"{args[1]}\" Succesfully copied");
                    }
                    else if (!File.Exists(args[2]))
                    {
                        MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to copy file", true);
                        Log.LogHandler.AddLog("Failed to copy file", Log.LogType.Output);
                    }
                }
                catch
                {
                    MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Enter a valid path", true);
                    Log.LogHandler.AddLog("Enter a valid path", Log.LogType.Output);
                }
            }
        }
    }
}
