﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.FileCommand
{
    public class cd : Command
    {
        public cd() : base("cd", "Change directory from one to another", User.ElevationType.Superior, new string[]
        {
            "Change current directory to directory specificly entered by user",
            @"cd [Path]",
            "\ncd command without any argument will show current directory path"
        }) { }

        public override void Execute(string[] args)
        {
            if(args.Length == 0)
            {
                Console.WriteLine(OSVariables.currentDirectory);
            }
            else if(args.Length > 0)
            {
                try
                {
                    OSVariables.currentDirectory = args[0];
                    Directory.SetCurrentDirectory(OSVariables.currentDirectory);
                }
                catch
                {
                    MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to change directory or directory doesnt exist", true);
                    Log.LogHandler.AddLog("Failed to change directory or directory doesnt exist", Log.LogType.Output);
                }
            }
        }
    }
}
