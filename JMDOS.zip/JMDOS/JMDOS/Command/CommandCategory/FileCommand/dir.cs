﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.FileCommand
{
    public class dir : Command
    {
        public dir() : base("dir", "create, and delete folders", User.ElevationType.Superior, new string[]
        {
            "Use to delete and create directory / folders",
            @"dir delete [Path]",
            @"dir create [Path]"
        }) { }

        public override void Execute(string[] args)
        {
            if (args[0] == "create")
            {
                try
                {
                    Directory.CreateDirectory(args[1]);
                    if(!Directory.Exists(args[1]))
                    {
                        MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to create directory", true);
                        Log.LogHandler.AddLog("Failed to create directory", Log.LogType.Output);
                    }
                    else if (Directory.Exists(args[1]))
                    {
                        MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Info, "Directory created succesfully", true);
                        Log.LogHandler.AddLog("Failed to create directory", Log.LogType.Output);
                    }
                }
                catch
                {
                    MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to create directory", true);
                    Log.LogHandler.AddLog("Failed to create directory", Log.LogType.Output);
                }
            }
            else if (args[0] == "delete")
            {
                try
                {
                    Directory.Delete(args[1]);
                    if(Directory.Exists(args[1]))
                    {
                        MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to create directory", true);
                        Log.LogHandler.AddLog("Failed to create directory", Log.LogType.Output);
                    }
                    else if (!Directory.Exists(args[1]))
                    {
                        MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Info, "Directory deleted succesfully", true);
                        Log.LogHandler.AddLog("Directory delete succesfully", Log.LogType.Output);
                    }
                }
                catch
                {
                    MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Failed to delete directory", true);
                    Log.LogHandler.AddLog("Failed to delete directory", Log.LogType.Output);
                }
            }
        }
    }
}
