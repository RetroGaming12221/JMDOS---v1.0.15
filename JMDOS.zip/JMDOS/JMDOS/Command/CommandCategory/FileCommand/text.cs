﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.FileCommand
{
    public class text : Command
    {
        public text() : base("text", "Open a console based text editor", User.ElevationType.User) { }

        public override void Execute(string[] args)
        {
            try
            {
                TextEditor.TextEdit.ProcessInstance(args);
            }
            catch
            {
                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Cannot open text editor or argument is null", true);
            }
        }
    }
}
