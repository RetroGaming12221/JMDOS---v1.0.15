﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command.CommandCategory.FileCommand
{
    public class ls : Command
    {
        public ls() : base("ls", "List all files and folder in current directory", User.ElevationType.Superior, new string[]
        {
            "List all files and folders on current directory / directory path",
            "ls [Path]",
            "\nls command wihtout any argument will list any files and folders in current directory"
        }) { }

        public override void Execute(string[] args)
        {
            try
            {
                if(args.Length == 0)
                {
                    string[] arrayDirectory = Directory.GetDirectories(OSVariables.currentDirectory);
                    string[] arrayFile = Directory.GetFiles(OSVariables.currentDirectory);

                    for(int i = 0; i < arrayDirectory.Length; i++)
                    {
                        Console.ForegroundColor = ConsoleColor.Green; Console.Write($"<Directory>"); Console.ForegroundColor = ConsoleColor.White; Console.Write($"{arrayDirectory[i]}\n");
                    }

                    for(int i = 0; i < arrayFile.Length; i++)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow; Console.Write($"<File>"); Console.ForegroundColor = ConsoleColor.White; Console.Write($"{arrayFile[i]}\n");
                    }
                }
                else if(args.Length > 0)
                {
                    string[] arrayDirectory = Directory.GetDirectories(args[0]);
                    string[] arrayFile = Directory.GetFiles(args[0]);

                    for (int i = 0; i < arrayDirectory.Length; i++)
                    {
                        Console.ForegroundColor = ConsoleColor.Green; Console.Write($"<Directory>"); Console.ForegroundColor = ConsoleColor.White; Console.Write($"{arrayDirectory[i]}\n");
                    }

                    for (int i = 0; i < arrayFile.Length; i++)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow; Console.Write($"<File>"); Console.ForegroundColor = ConsoleColor.White; Console.Write($"{arrayFile[i]}\n");
                    }
                }
            }
            catch
            {
                MessageHandle.Message.MessageProcces(MessageHandle.MessageType.Error, "Error occured", true);
                Log.LogHandler.AddLog("Error occured", Log.LogType.Output);
            }
        }
    }
}
