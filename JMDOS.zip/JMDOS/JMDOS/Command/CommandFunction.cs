﻿using JMDOS.User.UserFunction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command
{
    public static class CommandFunction
    {
        public static void Procces(string input)
        {
            string[] splited = input.Split(' ');
            string command = splited[0];
            List<string> args = new List<string>();

            foreach (var i in splited)
            {
                if(i != splited[0])
                {
                    args.Add(i);
                }
            }

            foreach (Command i in OSVariables.commandList)
            {
                if(i.Name == command)
                {
                    if(OSVariables.CurrentElevationType == User.ElevationType.User)
                    {
                        if(i.ElevationType == User.ElevationType.User)
                        {
                            i.Execute(args.ToArray());
                        }
                        else if(i.ElevationType == User.ElevationType.Superior)
                        {
                            bool result = UserFunc.Login(false);
                            if(result)
                            {
                                i.Execute(args.ToArray());
                            }
                            else if(!result)
                            {
                                Console.WriteLine("Failed to execute passwordA");
                            }
                        }
                        else if(i.ElevationType == User.ElevationType.Authority)
                        {
                            bool result = UserFunc.Login(true);
                            if (result)
                            {
                                i.Execute(args.ToArray());
                            }
                            else if (!result)
                            {
                                Console.WriteLine("Failed to execute passwordA");
                            }
                        }
                    }
                    else if(OSVariables.CurrentElevationType == User.ElevationType.Superior)
                    {
                        if (i.ElevationType == User.ElevationType.User)
                        {
                            i.Execute(args.ToArray());
                        }
                        else if (i.ElevationType == User.ElevationType.Superior)
                        {
                            i.Execute(args.ToArray());
                        }
                        else if (i.ElevationType == User.ElevationType.Authority)
                        {
                            bool result = UserFunc.Login(true);
                            if (result)
                            {
                                i.Execute(args.ToArray());
                            }
                            else if (!result)
                            {
                                Console.WriteLine("Failed to execute passwordA");
                            }
                        }
                    }
                    else if(OSVariables.CurrentElevationType == User.ElevationType.Authority)
                    {

                        if (i.ElevationType == User.ElevationType.User)
                        {
                            i.Execute(args.ToArray());
                        }
                        else if (i.ElevationType == User.ElevationType.Superior)
                        {
                            i.Execute(args.ToArray());
                        }
                        else if (i.ElevationType == User.ElevationType.Authority)
                        {
                            i.Execute(args.ToArray());
                        }
                    }
                }
            }
        }
    }
}
