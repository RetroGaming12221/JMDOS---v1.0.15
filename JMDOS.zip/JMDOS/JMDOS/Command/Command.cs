﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.Command
{
    public abstract class Command
    {
        public List<Command> commandList = new List<Command>();
        public Command(string name, string desc, User.ElevationType elevationType)
        {
            Name = name;
            Desc = desc;
            ElevationType = elevationType;
        }

        public Command(string name, string desc, User.ElevationType elevationType, string[] fullDesc)
        {
            Name = name;
            Desc = desc;
            ElevationType = elevationType;
            FullDesc = fullDesc;
        }

        public string Name { get; }
        public string Desc { get; }
        public User.ElevationType ElevationType { get; }
        public string[] FullDesc { get; }

        public abstract void Execute(string[] args);
    }
}
