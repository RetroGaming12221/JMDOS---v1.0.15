﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS
{
    public static class OSVariables
    {
        public static string currentDirectory = @"0:\";

        public static string OSVersion = "1.0.15";

        public static List<Command.Command> commandList = new List<Command.Command>()
        {
            new Command.CommandCategory.BasicCommand.ca(),
            new Command.CommandCategory.BasicCommand.echo(),
            new Command.CommandCategory.BasicCommand.help(),
            new Command.CommandCategory.BasicCommand.math(),
            new Command.CommandCategory.BasicCommand.osver(),
            new Command.CommandCategory.BasicCommand.clear(),

            new Command.CommandCategory.FileCommand.file(),
            new Command.CommandCategory.FileCommand.ls(),
            new Command.CommandCategory.FileCommand.dir(),
            new Command.CommandCategory.FileCommand.cd(),
            new Command.CommandCategory.FileCommand.text(),

            new Command.CommandCategory.SystemCommand.login(),
        };

        public static List<Log.Log> logList = new List<Log.Log>();

        public static string publicUserFolder = @"0:\System\User\Public";

        public static string defaultUsername = "default";
        public static string defaultPassword = "default";
        public static User.ElevationType defaultElevationType = User.ElevationType.Superior;
        public static string defaultUserFolder = @"0:\System\User\Default";

        public static string authorityUsername = "authority";
        public static string authorityPassword = "auth1234";
        public static User.ElevationType authorityElevationType = User.ElevationType.Authority;
        public static string authorityUserFolder = @"0:\System\User\Authority";

        public static string CurrentUsername = "Guest";
        public static string CurrentPassword = "";
        public static User.ElevationType CurrentElevationType = User.ElevationType.User;
    }
}
