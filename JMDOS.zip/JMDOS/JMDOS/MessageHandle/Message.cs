﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace JMDOS.MessageHandle
{
    public static class Message
    {
        public static void MessageProcces(MessageType messageType, string Message, bool NewLine)
        {
            if(messageType == MessageType.Info)
            {
                if(NewLine)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write($"\n[INFO]: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{Message}\n");
                    Console.ResetColor();
                }
                else if(!NewLine)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.Write($"\n[INFO]: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{Message}");
                    Console.ResetColor();
                }
            }
            else if(messageType == MessageType.Warning)
            {
                if(NewLine)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write($"\n[WARNING]: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{Message}\n");
                    Console.ResetColor();
                }
                else if(!NewLine)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write($"\n[WARNING]: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{Message}");
                    Console.ResetColor();
                }
            }
            else if (messageType == MessageType.Error)
            {
                if(NewLine)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"\n[ERROR]: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{Message}\n");
                    Console.ResetColor();
                }
                else if(!NewLine)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write($"\n[ERROR]: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{Message}");
                    Console.ResetColor();
                }
            }
            else if (messageType == MessageType.Fatal)
            {
                if(NewLine)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.Write($"\n[FATAL]: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{Message}\n");
                    Console.ResetColor();
                }
                else if(!NewLine)
                {
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.Write($"\n[FATAL]: ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write($"{Message}");
                    Console.ResetColor();
                }
            }
        }
    }
}
